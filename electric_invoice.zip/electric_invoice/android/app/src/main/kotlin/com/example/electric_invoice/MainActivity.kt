package com.example.electric_invoice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
