import 'package:flutter/material.dart';

const Color kColorGrey=Colors.grey;
const Color kColorWhite=Colors.white;
const Color kColorBlue=Color(0xff556DFB);
const Color kColorLight=Color(0xff5EDBAE);
const Color kColorDarkBlue=Color(0xff0E0121);
const Color kColorBackground=Color(0xffF5F5F5);

const Color kColor1=Color(0xff5edbae);
const Color kColor2=Color(0xff9747FF);
const Color kColor3=Color(0xff9747FF);
const Color kColor4=Color(0xffFFB800);
const Color kColor5=Color(0xff566EFC);
const Color kColor6=Color(0xff5332FB);
const Color kColor7=Color(0xff1FC0D1);
const Color kColor8=Color(0xff566EFC);
const Color kColor9=Color(0xff808080);
const Color kColor10=Color(0xff9747FF);
const Color kColor11=Color(0xffFFB800);